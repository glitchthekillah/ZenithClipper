# Native video component

AOT-compatible Windows library for WGC capture on an automatically selected NVIDIA D3D11 device and direct synchronous NVENC H.264 output. Build `build-native.ps1` once with the repository-local MSVC/SDK toolchain, then build/publish the consumer normally. The native DLL is copied transitively to build and publish outputs.

```csharp
using ZenithClipper.Native.Video;

using var recorder = new NativeVideoRecorder(
    new NativeVideoConfiguration { MonitorIndex = 0, FrameRate = 0, Quantizer = 20 },
    (ReadOnlySpan<byte> annexB, long frameIndex, bool keyFrame) =>
    {
        // Consume synchronously or copy encoded bytes before returning.
        muxer.WriteVideo(annexB, frameIndex, keyFrame);
    });

// These are resolved from display metadata before Start, so create the muxer first.
int width = recorder.Width, height = recorder.Height, fps = recorder.FrameRate;
recorder.CaptureFault += error => ReportCaptureFault(error);
recorder.Start();
// Later: Stop joins the capture worker and flushes the encoder.
recorder.Stop();
```

`VideoPacketHandler` receives one Annex B access unit. Its span remains valid only inside the callback while NVENC's output buffer is locked. Packet frame indices start at zero, with a constant time base of `1 / recorder.FrameRate`. IDR frames are forced every two seconds, with SPS/PPS repeated. The callback runs on the capture worker and must not retain the span or block on work that needs that same worker. Slow callbacks introduce encoding/pacing delay rather than an unbounded queue.

Managed callback exceptions are caught before returning through the C ABI. The worker then stores the original exception in `Fault`, raises `CaptureFault`, and cleans up. Event-handler exceptions are contained. `Stop` can be called from a packet/fault callback; in that case it requests stop without joining itself. `Start` initializes a dedicated MTA worker and waits up to 15 seconds. Each instance can start only once. `Stop` waits up to ten seconds; a stuck native driver requires the enclosing daemon's process watchdog because .NET cannot safely abort an in-progress driver call.

`NativeVideoStatistics` reports encoded/captured/repeated frame counts, strict pacing deadline misses, encoded byte count, and elapsed capture time. If WGC does not update, the recorder safely re-encodes the last owned texture. One owned BGRA texture is reused only after blocking bitstream completion. A GPU event query completes each WGC-to-owned-texture copy before returning the borrowed capture frame. There is no CPU pixel readback or FFmpeg worker.

Configuration:

- `MonitorIndex`: zero is primary; other monitors follow native enumeration order.
- `FrameRate`: zero resolves current monitor refresh rate; otherwise 1..240.
- `Quantizer`: constant QP 0..51; default 20.
- `FramePoolBuffers`: 1 or 2; default 1.
- `OutputPath`: optional diagnostic raw H.264 file; null disables native file output.
- `OutputWidth`/`OutputHeight`: zero means native dimensions. **GPU resize is not implemented.** Explicit dimensions matching native are accepted; any actual resize throws before capture starts.

There is no AMD encoder fallback in this component. A supported NVIDIA adapter is required. Display geometry changes/device loss are reported as faults; session recovery belongs to the daemon. This component handles video only and does not change display configuration, system timer resolution, or audio routing.

Validation: `tests/NativeVideoComponent` NativeAOT harness produced 841 sequential callback packets at native 2560x1600, resolved FPS0 to165, emitted three IDRs across roughly five seconds, and stopped normally. All 841 frames software-decoded without errors. The separate injected exception test failed the packet callback at index10, raised the original fault, cleaned up, and exited successfully. Sampled working set peaked at 91,070,464 bytes (86.85 MiB), excluding controller/audio/mux integration. Logs and decode evidence are under that test directory. Process working set is not interchangeable with private commit or GPU allocation.

The complete NVIDIA MIT header license remains in `native/nvEncodeAPI.h`; header source is FFmpeg nv-codec-headers n13.0.19.0. The NVIDIA driver DLL is loaded from System32 and is not bundled.
