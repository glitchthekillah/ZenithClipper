using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using Windows.Graphics.Capture;
using Windows.Graphics.DirectX;
using Windows.Graphics.DirectX.Direct3D11;

namespace ZenithClipper.Native.Video;

/// <summary>One worker owns WGC, its NVIDIA D3D11 device, and a synchronous, bounded NVENC encoder.</summary>
public sealed unsafe class NativeVideoRecorder : IDisposable
{
    // Load once on the caller before creating the COM/GPU worker; avoid lazy native binding inside that worker.
    private static readonly Lazy<nint> ShimModule = new(() => NativeLibrary.Load(Path.Combine(AppContext.BaseDirectory, "nvenc_shim.dll")));
    private readonly object lifecycle = new();
    private readonly NativeVideoConfiguration configuration;
    private readonly VideoPacketHandler packetHandler;
    private readonly DisplayInterop.Display display;
    private readonly TaskCompletionSource<bool> ready = new(TaskCreationOptions.RunContinuationsAsynchronously);
    private Thread? worker;
    private int started, stopping, disposed;
    private long encoded, captured, repeated, missed, bytes, startTimestamp, elapsedTicks;
    private Exception? fault, callbackFault;
    public event Action<Exception>? CaptureFault;
    /// <summary>Runs once on the video OS worker after the last packet/flush, before COM teardown.</summary>
    public event Action? WorkerFinishing;
    public int Width { get; }
    public int Height { get; }
    public int SourceWidth => display.Width;
    public int SourceHeight => display.Height;
    public int FrameRate { get; }
    public Exception? Fault => Volatile.Read(ref fault);
    public bool IsRunning => worker?.IsAlive == true && Volatile.Read(ref stopping) == 0;
    public NativeVideoStatistics Statistics => new(Interlocked.Read(ref encoded), Interlocked.Read(ref captured),
        Interlocked.Read(ref repeated), Interlocked.Read(ref missed), Interlocked.Read(ref bytes),
        TimeSpan.FromSeconds((double)Interlocked.Read(ref elapsedTicks) / Stopwatch.Frequency));

    public NativeVideoRecorder(NativeVideoConfiguration configuration, VideoPacketHandler packetHandler)
    {
        ArgumentNullException.ThrowIfNull(configuration); ArgumentNullException.ThrowIfNull(packetHandler);
        if (configuration.FrameRate < 0 || configuration.FrameRate > 1000 || configuration.FrameRate == 1 || configuration.Quantizer < 0 || configuration.Quantizer > 51 ||
            configuration.FramePoolBuffers is < 1 or > 2 || configuration.OutputWidth < 0 || configuration.OutputHeight < 0)
            throw new ArgumentOutOfRangeException(nameof(configuration));
        this.configuration = configuration; this.packetHandler = packetHandler;
        display = DisplayInterop.Select(configuration.MonitorIndex);
        Width = configuration.OutputWidth > 0 ? Math.Max(2, configuration.OutputWidth & ~1) : display.Width;
        Height = configuration.OutputHeight > 0 ? Math.Max(2, configuration.OutputHeight & ~1) :
            configuration.OutputWidth > 0 ? Math.Max(2, (int)((long)Width * display.Height / display.Width) & ~1) : display.Height;
        if ((Width & 1) != 0 || (Height & 1) != 0) throw new NotSupportedException("H.264 4:2:0 requires even dimensions.");
        FrameRate = configuration.FrameRate > 0 ? configuration.FrameRate : display.RefreshRate;
    }
    public void Start()
    {
        lock (lifecycle)
        {
        ObjectDisposedException.ThrowIf(Volatile.Read(ref disposed) != 0, this);
        _ = ShimModule.Value;
        if (Interlocked.CompareExchange(ref started, 1, 0) != 0) throw new InvalidOperationException("A recorder instance can be started only once.");
        worker = new Thread(CaptureWorker) { IsBackground = true, Name = "Zenith native video" };
        worker.Start();
        }
        try { ready.Task.WaitAsync(TimeSpan.FromSeconds(15)).GetAwaiter().GetResult(); }
        catch { Volatile.Write(ref stopping, 1); throw; }
    }
    public void Stop()
    {
        Volatile.Write(ref stopping, 1);
        Thread? captureThread = worker;
        if (captureThread is not null && captureThread != Thread.CurrentThread && !captureThread.Join(TimeSpan.FromSeconds(10)))
            throw new TimeoutException("The native video driver did not stop within ten seconds.");
    }
    public void Dispose()
    {
        if (Interlocked.Exchange(ref disposed, 1) == 0) Stop();
    }
    private void CaptureWorker()
    {
        nint factory = 0, adapter = 0, device = 0, context = 0, dxgi = 0, inspectable = 0, encoder = 0;
        GCHandle callbackHandle = default;
        bool initialized = false;
        try
        {
            TraceStage("COM init"); CheckHResult(RoInitialize(1)); initialized = true;
            Guid factoryId = new("770aae78-f26f-4dba-a829-253c83d1b387");
            CheckHResult(CreateDXGIFactory1(ref factoryId, out factory));
            adapter = FindNvidiaAdapter(factory);
            CheckHResult(D3D11CreateDevice(adapter, 0, 0, 0x20, 0, 0, 7, out device, out _, out context));
            TraceStage("D3D device ready");
            dxgi = Query(device, new Guid("54ec77fa-1377-44e6-8c32-88fd5f44c84c"));
            CheckHResult(CreateDirect3D11DeviceFromDXGIDevice(dxgi, out inspectable));
            using IDirect3DDevice projected = WinRT.MarshalInterface<IDirect3DDevice>.FromAbi(inspectable);
            GraphicsCaptureItem item = CreateItem(display.Monitor);
            if (item.Size.Width != SourceWidth || item.Size.Height != SourceHeight)
                throw new InvalidOperationException("The display configuration changed before capture started.");
            TraceStage("NVENC create");
            CheckNative(nc_create(device, (uint)Width, (uint)Height, (uint)FrameRate, (uint)configuration.Quantizer,
                configuration.OutputPath, out encoder));
            TraceStage("NVENC ready / resize configure");
            if (Width != SourceWidth || Height != SourceHeight)
                CheckNative(nc_configure_resize(encoder, (uint)SourceWidth, (uint)SourceHeight));
            TraceStage("Resize configured");
            callbackHandle = GCHandle.Alloc(this);
            nc_set_callback(encoder, &DeliverPacket, GCHandle.ToIntPtr(callbackHandle));
            using Direct3D11CaptureFramePool pool = Direct3D11CaptureFramePool.CreateFreeThreaded(
                projected, DirectXPixelFormat.B8G8R8A8UIntNormalized, configuration.FramePoolBuffers, item.Size);
            using GraphicsCaptureSession session = pool.CreateCaptureSession(item);
            TraceStage($"WGC default MinUpdateInterval ticks={session.MinUpdateInterval.Ticks}");
            session.MinUpdateInterval = TimeSpan.Zero;
            TraceStage("WGC start / MinUpdateInterval zero"); session.StartCapture();
            long wait = Stopwatch.GetTimestamp();
            Direct3D11CaptureFrame? first = null;
            while (first is null && !IsStopping() && Stopwatch.GetElapsedTime(wait).TotalSeconds < 5)
            { first = pool.TryGetNextFrame(); if (first is null) Thread.Sleep(1); }
            if (first is null) throw new TimeoutException("No capture frame arrived within five seconds.");
            TraceStage("First frame copy");
            using (first) { Copy(encoder, first); Interlocked.Increment(ref captured); }
            TraceStage("Copy complete");
            using HighResolutionPacer pacer = new();
            Stopwatch clock = Stopwatch.StartNew();
            startTimestamp = Stopwatch.GetTimestamp();
            ready.TrySetResult(true);
            for (long index = 0; !IsStopping(); index++)
            {
                pacer.WaitUntil(clock, (double)index / FrameRate, ref stopping);
                if (IsStopping()) break;
                using (Direct3D11CaptureFrame? frame = pool.TryGetNextFrame())
                {
                    if (frame is null) Interlocked.Increment(ref repeated);
                    else { Copy(encoder, frame); Interlocked.Increment(ref captured); }
                }
                CheckNative(nc_encode(encoder, (ulong)index * 10_000_000 / (uint)FrameRate));
                if (clock.Elapsed.TotalSeconds > (double)(index + 1) / FrameRate) Interlocked.Increment(ref missed);
                Interlocked.Exchange(ref elapsedTicks, Stopwatch.GetTimestamp() - startTimestamp);
            }
            CheckNative(nc_flush(encoder));
        }
        catch (Exception error)
        {
            Volatile.Write(ref fault, error); Volatile.Write(ref stopping, 1);
            ready.TrySetException(error);
            try { CaptureFault?.Invoke(error); } catch { /* Subscriber exceptions cannot escape the worker. */ }
        }
        finally
        {
            try { WorkerFinishing?.Invoke(); }
            catch (Exception error)
            {
                // Cleanup continues; preserve an earlier capture/callback failure as the primary fault.
                if (Fault is null)
                {
                    Volatile.Write(ref fault, error); Volatile.Write(ref stopping, 1);
                    ready.TrySetException(error);
                    try { CaptureFault?.Invoke(error); } catch { }
                }
            }
            if (encoder != 0) nc_destroy(encoder);
            if (callbackHandle.IsAllocated) callbackHandle.Free();
            Release(inspectable); Release(dxgi); Release(context); Release(device); Release(adapter); Release(factory);
            if (initialized) RoUninitialize();
            if (startTimestamp != 0) Interlocked.Exchange(ref elapsedTicks, Stopwatch.GetTimestamp() - startTimestamp);
        }
    }
    private static void TraceStage(string stage)
    { if (Environment.GetEnvironmentVariable("ZENITH_NATIVE_VIDEO_TRACE") == "1") Console.Error.WriteLine($"{DateTime.UtcNow:O} {stage}"); }
    private bool IsStopping() => Volatile.Read(ref stopping) != 0;
    [UnmanagedCallersOnly(CallConvs = [typeof(CallConvCdecl)])]
    private static int DeliverPacket(nint user, byte* data, uint length, ulong frameIndex, uint key)
    {
        NativeVideoRecorder? recorder = null;
        try
        {
            recorder = (NativeVideoRecorder)GCHandle.FromIntPtr(user).Target!;
            recorder.packetHandler(new ReadOnlySpan<byte>(data, checked((int)length)), checked((long)frameIndex), key != 0);
            Interlocked.Increment(ref recorder.encoded); Interlocked.Add(ref recorder.bytes, length);
            return 0;
        }
        catch (Exception error)
        {
            if (recorder is not null) { recorder.callbackFault = error; Volatile.Write(ref recorder.stopping, 1); }
            return -4096; // The exception is rethrown after the native call returns normally.
        }
    }
    private void CheckNative(int status)
    {
        if (status != 0) throw callbackFault ?? new InvalidOperationException(Marshal.PtrToStringAnsi(nc_error()) ?? $"NVENC status {status}");
    }
    private static void Copy(nint encoder, Direct3D11CaptureFrame frame)
    {
        nint abi = WinRT.MarshalInterface<IDirect3DSurface>.FromManaged(frame.Surface);
        try
        {
            int result = nc_copy_surface(encoder, abi);
            if (result != 0) throw new InvalidOperationException(Marshal.PtrToStringAnsi(nc_error()) ?? "GPU copy failed.");
        }
        finally { Marshal.Release(abi); }
    }
    private static nint FindNvidiaAdapter(nint factory)
    {
        for (uint index = 0; ; index++)
        {
            nint adapter = 0;
            int result = ((delegate* unmanaged[Stdcall]<nint, uint, nint*, int>)Table(factory)[12])(factory, index, &adapter);
            if (result == unchecked((int)0x887A0002)) break;
            CheckHResult(result);
            byte* description = stackalloc byte[312];
            try
            {
                CheckHResult(((delegate* unmanaged[Stdcall]<nint, void*, int>)Table(adapter)[10])(adapter, description));
                if (*(uint*)(description + 256) == 0x10de) return adapter;
            }
            catch { Release(adapter); throw; }
            Release(adapter);
        }
        throw new NotSupportedException("A supported NVIDIA GPU is required by the native video encoder.");
    }
    private static GraphicsCaptureItem CreateItem(nint monitor)
    {
        string name = "Windows.Graphics.Capture.GraphicsCaptureItem";
        CheckHResult(WindowsCreateString(name, name.Length, out nint hstring));
        nint interop = 0, item = 0;
        try
        {
            Guid iid = new("3628e81b-3cac-4c60-b7f4-23ce0e0c3356");
            CheckHResult(RoGetActivationFactory(hstring, ref iid, out interop));
            Guid itemId = new("79c3f95b-31f7-4ec2-a464-632ef5d30760");
            CheckHResult(((delegate* unmanaged[Stdcall]<nint, nint, Guid*, nint*, int>)Table(interop)[4])(interop, monitor, &itemId, &item));
            return WinRT.MarshalInterface<GraphicsCaptureItem>.FromAbi(item);
        }
        finally { Release(item); Release(interop); WindowsDeleteString(hstring); }
    }
    private static nint* Table(nint p) => *(nint**)p;
    private static nint Query(nint p, Guid iid)
    { nint result = 0; CheckHResult(((delegate* unmanaged[Stdcall]<nint, Guid*, nint*, int>)Table(p)[0])(p, &iid, &result)); return result; }
    private static void Release(nint p) { if (p != 0) ((delegate* unmanaged[Stdcall]<nint, uint>)Table(p)[2])(p); }
    private static void CheckHResult(int hr) { if (hr < 0) Marshal.ThrowExceptionForHR(hr); }
    [DllImport("dxgi.dll")] private static extern int CreateDXGIFactory1(ref Guid iid, out nint factory);
    [DllImport("d3d11.dll")] private static extern int D3D11CreateDevice(nint adapter, int driverType, nint software, uint flags,
        nint featureLevels, uint featureLevelCount, uint sdkVersion, out nint device, out int featureLevel, out nint context);
    [DllImport("d3d11.dll")] private static extern int CreateDirect3D11DeviceFromDXGIDevice(nint dxgi, out nint inspectable);
    [DllImport("combase.dll")] private static extern int RoInitialize(uint type);
    [DllImport("combase.dll")] private static extern void RoUninitialize();
    [DllImport("combase.dll", CharSet = CharSet.Unicode)] private static extern int WindowsCreateString(string text, int length, out nint value);
    [DllImport("combase.dll")] private static extern int WindowsDeleteString(nint value);
    [DllImport("combase.dll")] private static extern int RoGetActivationFactory(nint value, ref Guid iid, out nint instance);
    [DllImport("nvenc_shim.dll", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)] private static extern int nc_create(nint device, uint width, uint height, uint fps, uint qp, string? output, out nint encoder);
    [DllImport("nvenc_shim.dll", CallingConvention = CallingConvention.Cdecl)] private static extern void nc_set_callback(nint encoder, delegate* unmanaged[Cdecl]<nint, byte*, uint, ulong, uint, int> callback, nint user);
    [DllImport("nvenc_shim.dll", CallingConvention = CallingConvention.Cdecl)] private static extern int nc_configure_resize(nint encoder, uint sourceWidth, uint sourceHeight);
    [DllImport("nvenc_shim.dll", CallingConvention = CallingConvention.Cdecl)] private static extern nint nc_error();
    [DllImport("nvenc_shim.dll", CallingConvention = CallingConvention.Cdecl)] private static extern int nc_copy_surface(nint encoder, nint surface);
    [DllImport("nvenc_shim.dll", CallingConvention = CallingConvention.Cdecl)] private static extern int nc_encode(nint encoder, ulong timestamp);
    [DllImport("nvenc_shim.dll", CallingConvention = CallingConvention.Cdecl)] private static extern int nc_flush(nint encoder);
    [DllImport("nvenc_shim.dll", CallingConvention = CallingConvention.Cdecl)] private static extern void nc_destroy(nint encoder);
}







